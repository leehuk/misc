require('util')

function tms_toggle(event)
    local player = game.players[event.player_index]

    if not player or not player.valid or not player.selected or not player.selected.valid then
        return
    end

    if player.selected.train and player.selected.train.valid then
        local train = player.selected.train
        if train.manual_mode == true then
            train.manual_mode = false
        else
            train.manual_mode = true
        end
    end
end

script.on_event("tms-toggle", tms_toggle)