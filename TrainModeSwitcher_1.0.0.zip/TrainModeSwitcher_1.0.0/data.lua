data:extend({
    {
        name = "tms-toggle",
        type = "custom-input",
        key_sequence = "CONTROL + SHIFT + Z",
        consuming = "none"
    }
})